package Lab09;

import java.io.Serializable;

public class SoccerPlayer implements Comparable<SoccerPlayer> , Serializable {
	
	//Instance Variables
	protected String name;
	protected int id;
	protected int age;
	protected String nationality;
	protected int overallRating;
	protected int potential;
	protected String club;
	protected String foot;
	protected String position;
	protected int jerseyNumber;

	//Constructor #1
	public SoccerPlayer(String name, int id, int age, String nationality, int overallRating, int potential, String club,
			String foot, String position, int jerseyNumber) {
		this.name = name;
		this.id = id;
		this.age = age;
		this.nationality = nationality;
		this.overallRating = overallRating;
		this.potential = potential;
		this.club = club;
		this.foot = foot;
		this.position = position;
		this.jerseyNumber = jerseyNumber;
	}
	
	//Constructor #2. 
	public SoccerPlayer() {

	}

	//Getter for Name
	public String getName() {
		return name;
	}

	//Setter for Name
	public void setName(String name) {
		this.name = name;
	}

	//Getter for Id
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	//Getter for Age
	public int getAge() {
		return age;
	}

	//Setter for Age
	public void setAge(int age) {
		this.age = age;
	}

	//Getter for Nationality
	public String getNationality() {
		return nationality;
	}

	//Setter for Nationality
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	//Getter for Overall Rating
	public int getOverallRating() {
		return overallRating;
	}

	//Setter for Overall Rating
	public void setOverallRating(int overallRating) {
		this.overallRating = overallRating;
	}

	//Getter for Potential
	public int getPotential() {
		return potential;
	}

	//Setter for Potential
	public void setPotential(int potential) {
		this.potential = potential;
	}

	//Getter for Club
	public String getClub() {
		return club;
	}

	//Setter for Set Club
	public void setClub(String club) {
		this.club = club;
	}

	//Getter for Foot
	public String getFoot() {
		return foot;
	}

	//Setter for Foot
	public void setFoot(String foot) {
		this.foot = foot;
	}

	//Getter for Position
	public String getPosition() {
		return position;
	}

	//Setter for Position
	public void setPosition(String position) {
		this.position = position;
	}

	//Getter for Jersey Number
	public int getJerseyNumber() {
		return jerseyNumber;
	}

	//Setter for Jersey Number
	public void setJerseyNumber(int jerseyNumber) {
		this.jerseyNumber = jerseyNumber;
	}

	//To String
	public String toString() {
		return "SoccerPlayer name= " + name + ", id= " + id + ", age= " + age + ", nationality= " + nationality
				+ ", overallRating= " + overallRating + ", potential= " + potential + ", club= " + club + ", foot= " + foot
				+ ", position= " + position + ", jerseyNumber= " + jerseyNumber;
	}

	@Override
	public int compareTo(SoccerPlayer o) {
		return this.name.compareTo(o.getName());
	}
}
