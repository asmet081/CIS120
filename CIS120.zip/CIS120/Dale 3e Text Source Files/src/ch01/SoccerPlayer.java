package ch01;

public class SoccerPlayer {
	
	protected String name;
	protected int id;
	protected int age;
	protected String nationality;
	protected int overallRating;
	protected int potential;
	protected String club;
	protected String foot;
	protected String position;
	protected int jerseyNumber;

	public SoccerPlayer(String name, int id, int age, String nationality, int overallRating, int potential, String club,
			String foot, String position, int jerseyNumber) {
		super();
		this.name = name;
		this.id = id;
		this.age = age;
		this.nationality = nationality;
		this.overallRating = overallRating;
		this.potential = potential;
		this.club = club;
		this.foot = foot;
		this.position = position;
		this.jerseyNumber = jerseyNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public int getOverallRating() {
		return overallRating;
	}

	public void setOverallRating(int overallRating) {
		this.overallRating = overallRating;
	}

	public int getPotential() {
		return potential;
	}

	public void setPotential(int potential) {
		this.potential = potential;
	}

	public String getClub() {
		return club;
	}

	public void setClub(String club) {
		this.club = club;
	}

	public String getFoot() {
		return foot;
	}

	public void setFoot(String foot) {
		this.foot = foot;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public int getJerseyNumber() {
		return jerseyNumber;
	}

	public void setJerseyNumber(int jerseyNumber) {
		this.jerseyNumber = jerseyNumber;
	}

	@Override
	public String toString() {
		return "SoccerPlayer [name=" + name + ", id=" + id + ", age=" + age + ", nationality=" + nationality
				+ ", overallRating=" + overallRating + ", potential=" + potential + ", club=" + club + ", foot=" + foot
				+ ", position=" + position + ", jerseyNumber=" + jerseyNumber + "]";
	}

}
