package ch02.stringLogs;

public class Practive {

	public static void main(String[] args) {


		//
		
		write a method lowestString() that returns the lowest alphabetical order string in the log.
		Can use compareTo:
		  string1.compareTo(string2) < 0 means that string1 is earlier in alphabetical order.

		String string1 = �Aardvark�;
		String string2 = �Cat�;
		System.out.println(�Difference:  � + string2.compareTo(string1));

		=> returns 2

		System.out.println(�Difference: � + string1.compareTo(string2));

		=> returns -2

		ArrayStringLog.java in Dale->ch02.stringLogs

		
		LLStringNode n1, n2;
		
		n1 = new LLStringNode("Packers");
		n2 = new LLStringNode(" ");
		
		LLStringNode currentNode = n1;
		
		while (currentNode != null) {
			if currentNode.getInfo().compareTo("Packers") == 0)
			System.out.println("found it!");
			currentNode = currentNode.getLink();
		}


}


