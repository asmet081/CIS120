package Lab04;

//This code got very VERY messing when I started importing everything.
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import ch01.SoccerPlayer;
import ch03.stacks.*;

public class SoccerLeague {

	// Creating an unbounded stack
	public static BoundedStackInterface<SoccerPlayer> stack = new ArrayStack<SoccerPlayer>(10);
	public static UnboundedStackInterface<SoccerPlayer> stack1 = new LinkedStack<SoccerPlayer>();

	public static BoundedStackInterface<SoccerPlayer> stack3 = new ArrayStack<SoccerPlayer>(20000);
	public static UnboundedStackInterface<SoccerPlayer> stack4 = new LinkedStack<SoccerPlayer>();

	public static void main(String[] args) throws FileNotFoundException {

		File file = new File("futbolDataShort.csv");
		File file2 = new File("futbolData.csv");

		// Creating a scanner for fubolDataShort and fubolDataLong
		Scanner inputFile = new Scanner(file);
		Scanner inputFile2 = new Scanner(file2, "UTF-8");

		// Reading the first lines of fubolDataShort and fubolDataLong
		String line = inputFile.nextLine();
		line = inputFile.nextLine();

		String line2 = inputFile2.nextLine();
		line2 = inputFile2.nextLine();

		// Creating a tokenizer that splits commas
		String[] tokens = line.split(",");

		while (inputFile.hasNextLine()) {
			line = inputFile.nextLine();
			tokens = line.split(",");
			SoccerPlayer player = new SoccerPlayer(tokens[2], Integer.parseInt(tokens[1]), Integer.parseInt(tokens[3]),
					tokens[4], Integer.parseInt(tokens[5]), Integer.parseInt(tokens[6]), tokens[7], tokens[8],
					tokens[9], Integer.parseInt(tokens[10]));

			stack.push(player);
			stack1.push(player);
		}

		while (inputFile2.hasNextLine()) {
			line2 = inputFile2.nextLine();
			tokens = line2.split(",", -1);
			SoccerPlayer player2 = new SoccerPlayer(tokens[2], parseWithDefault(tokens[1], 0), parseWithDefault(tokens[3], 0),
					tokens[4], parseWithDefault(tokens[5], 0), parseWithDefault(tokens[6], 0), tokens[7], tokens[8],
					tokens[9], parseWithDefault(tokens[10], 0));

			stack3.push(player2);
			stack4.push(player2);
		}

		// Printing out stack top and find1
		//ArrayStack Short
		System.out.println(("Found!") + (" ") + find("Cristiano Ronaldo"));
		
		// Printing out stack1 top and find2
		//LinkedStack Short
		System.out.println(("Found!") + (" ") + find2("K. De Bruyne"));
		
		// Printing out stack3 top and find3
		//ArrayStack Long
		System.out.println(("Found!") + (" ") + find3("Neymar Jr"));
		
		// Printing out stack4 top and find4
		//LinkedStack Long
		System.out.println(("Found!") + (" ") + find4("Cristiano Ronaldo"));
		
		// Printing out stack top and find1
		//ArrayStack Short
		System.out.println(("Found!") + (" ") + find("NOT A REAL PERSON LOL"));
		
		inputFile.close();
		inputFile2.close();

	}

	
	//I had trouble figuring out how to write it in one method
	//Its a mess but I have it for 4 different methods
	
	public static String find(String name) {
		
		while (!stack.isEmpty()) { //While stack is not empty
			if (stack.top().getName().compareTo(name) == 0) //The stack is compartng the top to the name
				return(stack.top().getName()); //Return the tops name
			stack.pop(); //Then pop the stack
		}

		return ("NO NAME FOUND!"); //Otherwise we are returning no name found if no name is found
	} //The rest is identical execpt the stack names are different
	
	public static String find2(String name) {
		
		while (!stack1.isEmpty()) {
			if (stack1.top().getName().compareTo(name) == 0)
				return(stack1.top().getName());
			stack1.pop();
		}

		return ("NO NAME FOUND!");
	}
	
	public static String find3(String name) {
		
		while (!stack3.isEmpty()) {
			if (stack3.top().getName().compareTo(name) == 0)
				return(stack3.top().getName());
			stack3.pop();
		}

		return ("NO NAME FOUND!");
	}
	
	public static String find4(String name) {
		
		while (!stack4.isEmpty()) {
			if (stack4.top().getName().compareTo(name) == 0)
				return(stack4.top().getName());
			stack4.pop();
		}

		return ("NO NAME FOUND!");
	}
	
	
	
	//Took from:
	//https://stackoverflow.com/questions/1486077/good-way-to-encapsulate-integer-parseint
	//09/24/2020
	public static int parseWithDefault(String number, int defaultVal) {
		  try {
		    return Integer.parseInt(number);
		  } catch (NumberFormatException e) {
		    return defaultVal;
		  }
		}
}
