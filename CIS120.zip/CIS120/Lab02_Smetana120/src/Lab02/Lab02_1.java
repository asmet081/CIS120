package Lab02;

public class Lab02_1 {

	public static void main(String[] args) {

		//10 Element Array called testArray
		int[] testArray = new int[10];

		//For loop of 10 x's sqaured
		for (int x = 0; x < 10; x++) {
			testArray[x] = x*x;
		}
		
		//Printing our testArray element
		for (int x = 0; x < 10; x++) {
			System.out.println(testArray[x]);
		}
	}

}
