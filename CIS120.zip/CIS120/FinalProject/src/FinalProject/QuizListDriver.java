package FinalProject;

public class QuizListDriver {

	public static void main(String[] args) {

		// Create a QuizList object.
		QuizList quizList = new QuizList(5);
		quizList.getQuizScoreFromKeyboard();
		System.out.println("The quiz scores for <Firstname Lastname> are: " + quizList);
		System.out.println("The overall quiz score is: " + quizList.getScore());
		System.out.println("The quiz letter grade is: " + quizList.getGrade());

	}

}
