module Lab05_Smetana120 {
}