package Lab03;

import java.io.*;
import java.util.Scanner;
import java.io.File;

public class Tester {

	public static void main(String[] args) throws FileNotFoundException {

		//Log for Names, Clubs, and Nationalities
		//Declared using the StringLogInterface and Allocated using ArrayStringLog
		StringLogInterface NamesLog = new ArrayStringLog("Names");
		StringLogInterface ClubsLog = new ArrayStringLog("Clubs");
		StringLogInterface NationalitiesLog = new ArrayStringLog("Nationalities");
		
		//Reading futbolDataShort file
		File file = new File("futbolDataShort.csv");
		
		//Creating a Scanner called inputFile and reading the file
		Scanner inputFile = new Scanner(file);
		
		// Read the first 2 lines from the file.
		String line = inputFile.nextLine();
		line = inputFile.nextLine();

		//Creating a loop that goes through all the lines
		while (inputFile.hasNextLine()) {
			line = inputFile.nextLine();

			//Creating a tokenizer that splits between commas
			String[] tokens = line.split(",");

			//Seperates the tokens
			NamesLog.insert(tokens[2]);
			ClubsLog.insert(tokens[7]);
			NationalitiesLog.insert(tokens[4]);

		}

		//Printing out the Logs
		System.out.print(NamesLog);
		System.out.println(" ");
		System.out.print(ClubsLog);
		System.out.println(" ");
		System.out.print(NationalitiesLog);
		
		// Close the file.
		inputFile.close();
		
	}
}
