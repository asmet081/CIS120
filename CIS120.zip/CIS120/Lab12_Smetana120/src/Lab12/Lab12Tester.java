package Lab12;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.Stack;

public class Lab12Tester {

	public static void main(String[] args) {
		
		//#1
		//Creating stack
		MyStack<String> stack1 = new MyStack<String>();
		
		//Adding to stack
		stack1.add("HI");
		stack1.add("MY");
		stack1.add("NAME");
		stack1.add("IS");
		stack1.add("ALEX");
		stack1.add("SMETANA!");
		stack1.add("BYE!");
		
		//Printing out stack & reverse
		System.out.println("Before reverse:" + stack1);
		System.out.println("With reverse:" + stack1.reverse());
		
		//#2
		//Creating Queue
		ConcurrentLinkedQueue<String> clq = new ConcurrentLinkedQueue<String>();
		
		//Adding to Queue
        clq.add("1"); 
        clq.add("2"); 
        clq.add("3"); 
        clq.add("4"); 
        clq.add("5"); 
        clq.add("6"); 
        clq.add("7"); 
        clq.add("8"); 
        clq.add("9"); 
        clq.add("10"); 
        
        //Printing out queue
        System.out.println(clq);
        
        //Removing one element
        clq.remove("1");
        
        //Printing out the removed 1 element
        System.out.println(clq);
        
        //Removing everything
        while(clq.peek() != null) {
        	clq.remove();
        }
        
        //Printing
        System.out.println(clq);
        

		

	}

}
