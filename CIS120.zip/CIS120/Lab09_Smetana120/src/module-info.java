module Lab09_Smetana120 {
}