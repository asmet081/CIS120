package Lab04;

public class LinkedStringLog implements StringLogInterface {
	protected LLStringNode log; // reference to first node of linked
								// list that holds the StringLog strings
	protected String name; // name of this StringLog

	public LinkedStringLog(String name)
	// Instantiates and returns a reference to an empty StringLog object
	// with name "name".
	{
		log = null;
		this.name = name;
	}

	public void insert(String element)
	// Precondition: This StringLog is not full.
	//
	// Places element into this StringLog.
	{
		LLStringNode newNode = new LLStringNode(element);
		newNode.setLink(log);
		log = newNode;
	}

	public boolean isFull()
	// Returns true if this StringLog is full, false otherwise.
	{
		return false;
	}

	public int size()
	// Returns the number of Strings in this StringLog.
	{
		int count = 0;
		LLStringNode node;
		node = log;
		while (node != null) {
			count++;
			node = node.getLink();
		}
		return count;
	}

	public boolean contains(String element)
	// Returns true if element is in this StringLog,
	// otherwise returns false.
	// Ignores case difference when doing string comparison.
	{
		LLStringNode node;
		node = log;

		while (node != null) {
			if (element.equalsIgnoreCase(node.getInfo())) // if they match
				return true;
			else
				node = node.getLink();
		}

		return false;
	}

	public void clear()
	// Makes this StringLog empty.
	{
		log = null;
	}

	public String getName()
	// Returns the name of this StringLog.
	{
		return name;
	}

	public String toString()
	// Returns a nicely formatted string representing this StringLog.
	{
		String logString = "Log: " + name + "\n\n";
		LLStringNode node;
		node = log;
		int count = 0;

		while (node != null) {
			count++;
			logString = logString + count + ". " + node.getInfo() + "\n";
			node = node.getLink();
		}

		return logString;
	}

	
	//This was all the changes I made
	public int howMany(String element) {   //As specified in directions

		int x = 0; //Variable set to 0 to add later
		LLStringNode currentNode = log; ///Making a currentNode thats setting equal to log

		do {
			if (currentNode.getInfo().compareTo(element) == 0) { //CurrentNode is comparing to element
				x++; //Add x if its equal
			}
			currentNode = currentNode.getLink();
		} while (currentNode.getLink() != null); //If it doesnt equal

		return x; //Return our counting variable

	}
}