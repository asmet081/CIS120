package Lab10_Smetana120;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.Scanner;
import ch08.trees.BSTInterface;

public class Tester{
	
	static BSTInterface<SoccerPlayer> bst = new BinarySearchTree<SoccerPlayer>(); //Creating tree
	
	public static void main(String[] args) throws FileNotFoundException {
		
		long startTime = System.nanoTime();
		readFromFile("futbolDataShort.csv", bst);//Read from file modified from last lab
		long estimatedTime = System.nanoTime() - startTime;
		SoccerPlayer soccerPlayer = new SoccerPlayer();
		soccerPlayer.setName("Cristiano Ronaldo"); //Setting name
		System.out.print("Tree:" + " "); //Printing out
		System.out.println(estimatedTime); //Printing out
		

		System.out.println(bst.extHowMany(soccerPlayer)); //Printing method1
		System.out.println(bst.howMany(soccerPlayer)); //Printing method2
	}
	
	
	public static String readFromFile(String fileName, BSTInterface<SoccerPlayer> bst) throws FileNotFoundException {
		File file = new File(fileName); // Creating new file to read what the user inputs
		Scanner inputFile = new Scanner(file); // Creating a Scanner

		String line = inputFile.nextLine(); // Inputing the next two lines
		line = inputFile.nextLine();

		String[] tokens = line.split(","); // Spliting on a ","

		while (inputFile.hasNextLine()) { // A loop that while it has a next line splits the tokens and assigns the
											// tokens to a soccer player object
			line = inputFile.nextLine();
			tokens = line.split(",", -1);
			SoccerPlayer player = new SoccerPlayer(tokens[2], parseWithDefault(tokens[1], 0),
					parseWithDefault(tokens[3], 0), tokens[4], parseWithDefault(tokens[5], 0),
					parseWithDefault(tokens[6], 0), tokens[7], tokens[8], tokens[9], parseWithDefault(tokens[10], 0));

			bst.add(player); // ONLY THING CHANGED in read from file
		}

		inputFile.close(); // Close file
		return fileName; // return file
	}
	
	
	//Recycled from old lab
	public static int parseWithDefault(String number, int defaultVal) {
		try {
			return Integer.parseInt(number);
		} catch (NumberFormatException e) {
			return defaultVal;
		}
	}
}
