package Lab06;

import ch03.stacks.ArrayStack;
import ch03.stacks.BoundedStackInterface;

public abstract class Tester {

	public static void main(String[] args) {


		//Creating a bunch of cards
		Card Heart1 = new Card(1, "Hearts");
		Card Heart2 = new Card(2, "Hearts");
		Card Heart3 = new Card(3, "Hearts");
		Card Heart4 = new Card(4, "Hearts");
		Card Heart5 = new Card(5, "Hearts");
		Card Heart6 = new Card(6, "Hearts");
		
		//Creating a stack
		CardDeckInterface<Card> Deck = new CardDeck<Card>(52);
		
		//Adding them to the deck
		Deck.addCard(Heart1);
		Deck.addCard(Heart2);
		Deck.addCard(Heart3);
		Deck.addCard(Heart4);
		Deck.addCard(Heart5);
		Deck.addCard(Heart6);
		
		//Deals N cards
		BoundedStackInterface<Card> Hand = Deck.dealNCards(3);
		System.out.println(Hand.top());
		
		System.out.println(Deck.dealOneCard());
		
	}

}
