package Lab02;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import Lab02.SoccerPlayer;

public class SoccerPlayerTester {

	//Main Method for testing the soccer player class
	public static void main(String[] args) throws IOException {

		// Open the file.
		File file = new File("futbolDataShort.txt");
		Scanner inputFile = new Scanner(file);

		// Read the first line from the file.
		String line = inputFile.nextLine();
		line = inputFile.nextLine();

		// Close the file.
		inputFile.close();
		
		String[] tokens = line.split("\t");
		
		SoccerPlayer player = new SoccerPlayer(tokens[2], Integer.parseInt(tokens[1]), Integer.parseInt(tokens[3]), tokens[4], Integer.parseInt(tokens[5]), Integer.parseInt(tokens[6]), tokens[7], tokens[8], tokens[9], Integer.parseInt(tokens[10]));
		
		System.out.println(player.toString());
		
	}
	

}

