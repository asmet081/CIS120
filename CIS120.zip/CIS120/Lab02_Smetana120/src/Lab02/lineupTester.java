package Lab02;

public class lineupTester {

	public static void main(String[] args) {
		
		//Using the Lineup class
		Lineup tester = new Lineup();
		
		//Creating an array for testing
		//Setting the Names so that they aren't just named none
		
		String[] Players = new String[9];
		
		for (int x = 0; x < 9; x++) {
			Players[x] = ("none" + x);
		}
		
		//Testing the set names of players method. It works!
		tester.setNamesOfPlayers(Players);
		
		//Testing the To String to make sure that it works
		System.out.println(tester.toString());
		
		System.out.println(" ");
		
		//Prints the next 3 batters
		tester.upNext();
		
		System.out.println(" ");
		
		//Just testing to make sure that it resets back to one. Shows the next 3 batters
		tester.setCurrentBatter(7);
		tester.upNext();
		
		System.out.println(" ");
		
		//Just testing to make sure that it resets back to one. Shows the next 3 batters
		tester.setCurrentBatter(8);
		tester.toNext();
		tester.upNext();
		
		System.out.println(" ");
		

	}

}
