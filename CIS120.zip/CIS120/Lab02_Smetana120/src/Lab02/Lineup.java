package Lab02;

import java.util.Arrays;

public class Lineup {

	//Initialize Variables
	protected String[] NamesOfPlayers = new String[9];
	protected int currentBatter;

	//Constructor #1
	public Lineup() {
		for (int x = 0; x < 9; x++) {
			NamesOfPlayers[x] = ("None");
			currentBatter = 0;
		}

	}

	//Constructor #2
	public Lineup(String[] namesOfPlayers, int currentBatter) {
		NamesOfPlayers = namesOfPlayers;
		this.currentBatter = currentBatter;
	}
	
	//The getters and setters made by the eclispe

	public String[] getNamesOfPlayers() {
		return NamesOfPlayers;
	}

	public void setNamesOfPlayers(String[] namesOfPlayers) {
		NamesOfPlayers = namesOfPlayers;
	}

	public int getCurrentBatter() {
		return currentBatter;
	}

	public void setCurrentBatter(int currentBatter) {
		this.currentBatter = currentBatter;
	}

	//ToNext Method
	//Advances batter and resets if reaches end
	public void toNext() {
		currentBatter++;
		if (currentBatter >= 8) {
			currentBatter = 0;
		}

	}

	//Prints out the next 3 batters/
	//There is probably an easier way to do this but it prings the next 3 batters if it reaches 7th and 8th batter
	public void upNext() {
		System.out.println(NamesOfPlayers[currentBatter]);

		if (currentBatter == 7) {
			System.out.println(NamesOfPlayers[8]);
			System.out.println(NamesOfPlayers[0]);
		} else {

			if (currentBatter == 8) {
				System.out.println(NamesOfPlayers[0]);
				System.out.println(NamesOfPlayers[1]);
			} else {
				System.out.println(NamesOfPlayers[currentBatter + 1]);
				System.out.println(NamesOfPlayers[currentBatter + 2]);
			}
		}

	}

	//To String pre made and slightly altered
	public String toString() {
		return " Lineup NamesOfPlayers: " + Arrays.toString(NamesOfPlayers) + ", currentBatter: " + currentBatter + " ";
	}
}
