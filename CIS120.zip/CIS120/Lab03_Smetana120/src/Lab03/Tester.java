//Alex Smetana
//CIS 120 - Lab03 - StringLog ADT's
//09/17/2020


package Lab03;

import java.io.*;
import java.util.Scanner;
import java.io.File;

public class Tester {

	public static void main(String[] args) throws FileNotFoundException {

		//Log for Names, Clubs, and Nationalities
		//Declared using the StringLogInterface and Allocated using ArrayStringLog
		//THESE ARE FOR FUTBOLDATATSHORT.CSV!
		StringLogInterface NamesLog = new ArrayStringLog("Names");
		StringLogInterface ClubsLog = new ArrayStringLog("Clubs");
		StringLogInterface NationalitiesLog = new ArrayStringLog("Nationalities");
		
		//THESE ARE FOR FUTBOLDATA
		StringLogInterface NamesLog2 = new ArrayStringLog("Names", 20000);
		StringLogInterface ClubsLog2 = new ArrayStringLog("Clubs", 20000);
		StringLogInterface NationalitiesLog2 = new ArrayStringLog("Nationalities", 20000);
		
		//Reading futbolDataShort file
		File file = new File("futbolDataShort.csv");
		File file2 = new File("futbolData.csv");
		
		//Creating a Scanner called inputFile and reading the file
		Scanner inputFile = new Scanner(file);
		Scanner inputFile2 = new Scanner(file2, "UTF-8");
		
		// Read the first 2 lines from the file.
		String line = inputFile.nextLine();
		line = inputFile.nextLine();
		
		// Read the first 2 lines from the file.
		String line2 = inputFile2.nextLine();
		line2 = inputFile2.nextLine();

		//Creating a loop that goes through all the lines
		while (inputFile.hasNextLine()) {
			line = inputFile.nextLine();

			//Creating a tokenizer that splits between commas
			String[] tokens = line.split(",");

			//Seperates the tokens
			NamesLog.insert(tokens[2]);
			ClubsLog.insert(tokens[7]);
			NationalitiesLog.insert(tokens[4]);

		}
		
		//Creating a loop that goes through all the lines
		while (inputFile2.hasNextLine()) {
			line2 = inputFile2.nextLine();

			//Creating a tokenizer that splits between commas
			String[] tokens2 = line2.split(",");

			//Seperates the tokens
			NamesLog2.insert(tokens2[2]);
			ClubsLog2.insert(tokens2[7]);
			NationalitiesLog2.insert(tokens2[4]);

		}

		//Printing out the Logs
		System.out.print(NamesLog);
		System.out.println(" ");
		System.out.print(ClubsLog);
		System.out.println(" ");
		System.out.print(NationalitiesLog);
		System.out.println(" ");
		
		//Printing out the Logs
		System.out.print(NamesLog2.howMany("Cristiano Ronaldo"));
		System.out.println(" ");
		System.out.print(ClubsLog2.howMany("Manchester United"));
		System.out.println(" ");
		System.out.print(NationalitiesLog2.howMany("England"));
		
		// Close the file.
		inputFile.close();
		inputFile2.close();
		
	}
}
