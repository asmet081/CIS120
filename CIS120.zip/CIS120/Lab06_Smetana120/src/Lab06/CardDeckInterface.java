package Lab06;

import ch03.stacks.BoundedStackInterface;

public interface CardDeckInterface<T> {
	
	  T dealOneCard() throws StackUnderflowException;
	  //Deals one card from the top
	  
	  BoundedStackInterface<T> dealNCards(int NumberOfCards) throws StackUnderflowException;
	  //Deals n cards from the top
	  
	  void addCard(T card) throws StackOverflowException;
	  //Add a card to the top of the deck

	  
}
