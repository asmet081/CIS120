package Lab04;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class tester {

	public static void main(String[] args) throws FileNotFoundException {

		//Reading the futbolDataSort and fubolData files
		File file = new File("futbolDataShort.csv");
		File file2 = new File("futbolData.csv");

		//Creating a scanner class for the files
		Scanner inputFile = new Scanner(file);
		Scanner inputFile2 = new Scanner(file2, "UTF-8");

		//Reading the next two lines of the files
		String line = inputFile.nextLine();
		line = inputFile.nextLine();
		
		//Reading the next two lines of the files
		String line2 = inputFile2.nextLine();
		line2 = inputFile2.nextLine();
		
		//Creating a tokenizer to split commas
		String[] tokens = line.split(",");
		String[] tokens2 = line2.split(",");
		
		StringLogInterface NationalitiesShort = new LinkedStringLog(tokens[4]);
		StringLogInterface NationalitiesLong = new LinkedStringLog(tokens[4]);
		
		while (inputFile.hasNextLine()) {  //While input has the next line
			line = inputFile.nextLine();   //Read every line
			tokens = line.split(",");      //Split every line on the comma
			NationalitiesShort.insert(tokens[4]); //insert every Nationalitie token

		}
		
		while (inputFile2.hasNextLine()) { //SAME AS ABOVE but for the long file
			line2 = inputFile2.nextLine();
			tokens2 = line2.split(",");
			NationalitiesLong.insert(tokens2[4]);

		}

		//Closing futbolDataShort and futbolData
		inputFile.close();
		inputFile2.close();
		
		//Printing out Nationalities to make sure that worked
		System.out.println(NationalitiesShort.toString());

		
		//Printing out the howmany method as specified in directions
		System.out.println(NationalitiesShort.howMany("Belgium"));

		long startTime = System.nanoTime();
		System.out.println(NationalitiesLong.howMany("Belgium"));
		long estimatedTime = System.nanoTime() - startTime;

		System.out.println(estimatedTime);

	}

}
