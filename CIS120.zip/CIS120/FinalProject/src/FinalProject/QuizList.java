package FinalProject;

import java.util.Scanner;

public class QuizList extends GradedActivity {

	int[] quizzes;
	int numberOfQuizzes;

	Scanner keyboard = new Scanner(System.in);

	public QuizList(int numQuizzes) {

		numberOfQuizzes = 0;
		quizzes = new int[numQuizzes];

	}

	public int[] getQuizScoreFromKeyboard() {
		for (int i = 0; i < quizzes.length; i++) {
			System.out.println("Enter a valid Quiz Score:");
			quizzes[i] = keyboard.nextInt();

			while (quizzes[i] < 0 || quizzes[i] > 10) {
				System.out.print("Please re-enter");
				quizzes[i] = keyboard.nextInt();
			}
		}

		this.calculateScore();
		return quizzes;
	}

	public void calculateScore() {

		int total = 0;

		for (int x = 0; x < quizzes.length; x++) {
			total += quizzes[x];
		}

		this.setScore(total / (double)quizzes.length * 10);

	}

	// I had trouble with the toString
	public String toString(int quizScore, int Score, int letterGrade) {
		return " " + quizScore + " " + Score + " " + letterGrade;
	}

}
