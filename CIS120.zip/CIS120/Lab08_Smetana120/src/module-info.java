module Lab08_Smetana120 {
}