package Lab09;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.*;
import java.util.Scanner;

import ch06.lists.*;

public class SeriazableTester {

	public static void main(String[] args) throws FileNotFoundException, IOException {

		ListInterface<SoccerPlayer> list = new ArrayUnsortedList<SoccerPlayer>(20000);

		readFromFile("futbolDataShort.csv", list);
		System.out.println(list.getNext());

		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("futbolDataSerialized.txt"));
	
		out.writeObject(list);
		out.close();
	}

	public static String readFromFile(String fileName, ListInterface<SoccerPlayer> list) throws FileNotFoundException {
		File file = new File(fileName); // Creating new file to read what the user inputs
		Scanner inputFile = new Scanner(file); // Creating a Scanner

		String line = inputFile.nextLine(); // Inputing the next two lines
		line = inputFile.nextLine();

		String[] tokens = line.split(","); // Spliting on a ","

		while (inputFile.hasNextLine()) { // A loop that while it has a next line splits the tokens and assigns the
											// tokens to a soccer player object
			line = inputFile.nextLine();
			System.out.println(line);
			tokens = line.split(",", -1);
			SoccerPlayer player = new SoccerPlayer(tokens[2], parseWithDefault(tokens[1], 0),
					parseWithDefault(tokens[3], 0), tokens[4], parseWithDefault(tokens[5], 0),
					parseWithDefault(tokens[6], 0), tokens[7], tokens[8], tokens[9], parseWithDefault(tokens[10], 0));

			list.add(player); // Adds onto list
		}

		inputFile.close(); // Close file
		return fileName; // return file
	}

	
	//copied from previous labs 
	public static int parseWithDefault(String number, int defaultVal) {
		try {
			return Integer.parseInt(number);
		} catch (NumberFormatException e) {
			return defaultVal;
		}
	}

}
