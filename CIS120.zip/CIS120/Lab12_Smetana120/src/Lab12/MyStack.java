package Lab12;
import java.util.Stack;

public class MyStack<E> extends Stack<E> {

	public Stack<E> reverse(){
		Stack<E> stack = new Stack<E>();

		while (!this.empty()) {
			stack.push(this.pop());
		}
		return stack;
		
	}
}
