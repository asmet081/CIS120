package Lab07;

import java.io.FileNotFoundException;

public class TesterClass1 {

	public static void main(String[] args) throws FileNotFoundException {
		
		SoccerPlayerQueue QueueShort = new SoccerPlayerQueue();
		SoccerPlayerQueue QueueLong = new SoccerPlayerQueue();
		
		QueueShort.readFromFile("futbolDataShort.csv");
		QueueLong.readFromFile("futbolData.csv");
		
		System.out.println(QueueShort.comprehensiveFind("Cristiano Ronaldo"));
		System.out.println(QueueLong.comprehensiveFind("Cristiano Ronaldo"));
	}

}
