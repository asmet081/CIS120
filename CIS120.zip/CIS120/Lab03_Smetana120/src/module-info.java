module Lab03_Smetana120 {
}