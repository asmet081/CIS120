module Lab02_Smetana120 {
}