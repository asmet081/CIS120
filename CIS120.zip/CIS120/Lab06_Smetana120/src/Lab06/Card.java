package Lab06;

public class Card {

	int number;
	String suit;
	
	
	//Construtor to call card
	public Card(int number, String suit) {
		super();
		this.number = number;
		this.suit = suit;
	}

	//To String to return card
	public String toString() {
		return ("Your Card:" + " " + suit + " " + number);
	}
	
}
