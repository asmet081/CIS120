package Lab13;

import ch03.stacks.LinkedStack;
import ch03.stacks.UnboundedStackInterface;
import ch05.queues.LinkedUnbndQueue;
import ch05.queues.UnboundedQueueInterface;
import ch09.graphs.WeightedGraph;
import ch09.graphs.WeightedGraphInterface;
import ch09.priorityQueues.Heap;
import ch09.priorityQueues.PriQueueInterface;
import support.Flight;

public class Tester {
	
	private static void shortestPaths(WeightedGraphInterface<String> graph, String startVertex)

//Writes the shortest distance from startVertex to every 
//other reachable vertex in graph.
	{
		Flight flight;
		Flight saveFlight; // for saving on priority queue
		int minDistance;
		int newDistance;

		PriQueueInterface<Flight> pq = new Heap<Flight>(20); // Assume at most 20 vertices
		String vertex;
		UnboundedQueueInterface<String> vertexQueue = new LinkedUnbndQueue<String>();

		graph.clearMarks();
		saveFlight = new Flight(startVertex, startVertex, 0);
		pq.enqueue(saveFlight);

		System.out.println("Last Vertex   Destination   Distance");
		System.out.println("------------------------------------");

		do {
			flight = pq.dequeue();
			if (!graph.isMarked(flight.getToVertex())) {
				graph.markVertex(flight.getToVertex());
				System.out.println(flight);
				flight.setFromVertex(flight.getToVertex());
				minDistance = flight.getDistance();
				vertexQueue = graph.getToVertices(flight.getFromVertex());
				while (!vertexQueue.isEmpty()) {
					vertex = vertexQueue.dequeue();
					if (!graph.isMarked(vertex)) {
						newDistance = minDistance + graph.weightIs(flight.getFromVertex(), vertex);
						saveFlight = new Flight(flight.getFromVertex(), vertex, newDistance);
						pq.enqueue(saveFlight);
					}
				}
			}
		} while (!pq.isEmpty());
		System.out.println();
		System.out.println("The unreachable vertices are:");
		vertex = graph.getUnmarked();
		while (vertex != null) {
			System.out.println(vertex);
			graph.markVertex(vertex);
			vertex = graph.getUnmarked();
		}
		System.out.println();
	}

	private static boolean isPath(WeightedGraphInterface<String> graph, String startVertex, String endVertex)

	// Returns true if a path exists on graph, from startVertex to endVertex;
	// otherwise returns false. Uses depth-first search algorithm.

	{
		UnboundedStackInterface<String> stack = new LinkedStack<String>();
		UnboundedQueueInterface<String> vertexQueue = new LinkedUnbndQueue<String>();

		boolean found = false;
		String vertex;
		String item;

		graph.clearMarks();
		stack.push(startVertex);
		do {
			vertex = stack.top();
			stack.pop();
			if (vertex == endVertex)
				found = true;
			else {
				if (!graph.isMarked(vertex)) {
					graph.markVertex(vertex);
					vertexQueue = graph.getToVertices(vertex);

					while (!vertexQueue.isEmpty()) {
						item = vertexQueue.dequeue();
						if (!graph.isMarked(item))
							stack.push(item);
					}
				}
			}
		} while (!stack.isEmpty() && !found);

		return found;
	}

	private static boolean isPath2(WeightedGraphInterface<String> graph, String startVertex, String endVertex)

//Returns true if a path exists on graph, from startVertex to endVertex; 
//otherwise returns false. Uses breadth-first search algorithm.

	{
		UnboundedQueueInterface<String> queue = new LinkedUnbndQueue<String>();
		UnboundedQueueInterface<String> vertexQueue = new LinkedUnbndQueue<String>();

		boolean found = false;
		String vertex;
		String item;

		graph.clearMarks();
		queue.enqueue(startVertex);
		do {
			vertex = queue.dequeue();
			if (vertex == endVertex)
				found = true;
			else {
				if (!graph.isMarked(vertex)) {
					graph.markVertex(vertex);
					vertexQueue = graph.getToVertices(vertex);

					while (!vertexQueue.isEmpty()) {
						item = vertexQueue.dequeue();
						if (!graph.isMarked(item))
							queue.enqueue(item);
					}
				}
			}
		} while (!queue.isEmpty() && !found);

		return found;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Creating the graph
		WeightedGraphInterface<String> graph = new WeightedGraph<String>();

		//Creating strings for the vertex's
		
		String vertex1 = new String("A");
		String vertex2 = new String("B");
		String vertex3 = new String("C");
		String vertex4 = new String("D");
		String vertex5 = new String("E");
		String vertex6 = new String("F");
		String vertex7 = new String("G");
		String vertex8 = new String("H");

		//Adding vertex's
		
		graph.addVertex(vertex1);
		graph.addVertex(vertex2);
		graph.addVertex(vertex3);
		graph.addVertex(vertex4);
		graph.addVertex(vertex5);
		graph.addVertex(vertex6);
		graph.addVertex(vertex7);
		graph.addVertex(vertex8);

		
		//Creating all the edges
		//I am aware of the shortcut method but I didn't notice it until I almost completed the lab Ugh
		graph.addEdge(vertex1, vertex2, 10);
		graph.addEdge(vertex2, vertex1, 10);

		graph.addEdge(vertex1, vertex3, 11);
		graph.addEdge(vertex3, vertex1, 11);

		graph.addEdge(vertex1, vertex4, 4);
		graph.addEdge(vertex4, vertex1, 4);

		graph.addEdge(vertex2, vertex4, 20);
		graph.addEdge(vertex4, vertex2, 20);

		graph.addEdge(vertex2, vertex3, 11);
		graph.addEdge(vertex3, vertex2, 11);

		graph.addEdge(vertex4, vertex5, 2);
		graph.addEdge(vertex5, vertex4, 2);

		graph.addEdge(vertex2, vertex5, 19);
		graph.addEdge(vertex5, vertex2, 19);

		graph.addEdge(vertex3, vertex6, 15);
		graph.addEdge(vertex6, vertex3, 15);

		graph.addEdge(vertex2, vertex6, 7);
		graph.addEdge(vertex6, vertex2, 7);

		graph.addEdge(vertex2, vertex7, 9);
		graph.addEdge(vertex7, vertex2, 9);

		graph.addEdge(vertex5, vertex7, 18);
		graph.addEdge(vertex7, vertex5, 18);

		graph.addEdge(vertex6, vertex7, 6);
		graph.addEdge(vertex7, vertex6, 6);

		graph.addEdge(vertex7, vertex8, 11);
		graph.addEdge(vertex8, vertex7, 11);

		graph.addEdge(vertex5, vertex8, 19);
		graph.addEdge(vertex8, vertex5, 19);

		boolean result;

		
		
		//Deph Search!
	    //The code is in order. Everything is true 
		
		System.out.println("depth first (Order of it)");

		result = isPath(graph, vertex1, vertex2);
		System.out.println("Vertex1(A) - Vertex2(B) " + result);

		result = isPath(graph, vertex2, vertex3);
		System.out.println("Vertex2(B) - Vertex3(C) " + result);

		result = isPath(graph, vertex3, vertex6);
		System.out.println("Vertex3(C) - Vertex6(F) " + result);

		result = isPath(graph, vertex6, vertex7);
		System.out.println("Vertex6(F) - Vertex7(G) " + result);

		result = isPath(graph, vertex7, vertex5);
		System.out.println("Vertex7(G) - Vertex5(E) " + result);

		result = isPath(graph, vertex5, vertex4);
		System.out.println("Vertex5(E) - Vertex4(D) " + result);
		
		result = isPath(graph, vertex5, vertex8);
		System.out.println("Vertex5(E) - Vertex8(H) " + result);
		
		
	    System.out.println();
	    System.out.println();
	    
	    
	    //Breath Search
	    //The code is in order. Everything is true 
		
	    System.out.println("Breath Search (Order of it)");
		result = isPath2(graph, vertex1, vertex2);
		System.out.println("Vertex1(A) - Vertex2(B) " + result);
		
		result = isPath(graph, vertex1, vertex3);
		System.out.println("Vertex1(A) - Vertex3(C) " + result);
		
		result = isPath(graph, vertex1, vertex4);
		System.out.println("Vertex1(A) - Vertex3(D) " + result);
		
		result = isPath(graph, vertex2, vertex5);
		System.out.println("Vertex2(B) - Vertex5(E) " + result);
		
		result = isPath(graph, vertex2, vertex6);
		System.out.println("Vertex2(B) - Vertex6(F) " + result);
		
		result = isPath(graph, vertex2, vertex7);
		System.out.println("Vertex5(B) - Vertex7(G) " + result);
		
		result = isPath(graph, vertex5, vertex8);
		System.out.println("Vertex5(E) - Vertex8(H) " + result);
		
		
		//The shortest path
	    System.out.println();
	    System.out.println();
	    shortestPaths(graph, vertex1);
	    
	   
	    graph.prims(vertex1);
	    graph.dijkstras(vertex1, vertex8);
	}


}
