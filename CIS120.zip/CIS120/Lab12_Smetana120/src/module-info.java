module Lab12_Smetana120 {
}