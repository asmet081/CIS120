package Lab14;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import ch10.*;

public class Tester {

	public static void main(String[] args) throws FileNotFoundException {

		System.out.println(f(4));
	}

	static public int f(int n) {
		int j;
		if (n == 1 || n == 2) {
			System.out.println("n=" + n);
			return n;
		} else {
			j = 3 * f(n - 1) + 2 * f(n - 2);
			System.out.println("n=" + n + " n-1=" + (n-1) + " n-2=" + (n-2) + " j=" + j);
			return j;
		}
	}
}
