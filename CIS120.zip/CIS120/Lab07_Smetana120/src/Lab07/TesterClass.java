package Lab07;

import java.io.FileNotFoundException;

import ch05.queues.UnboundedQueueInterface;

public class TesterClass {

	public static void main(String[] args) throws FileNotFoundException {
		
		
		SoccerPlayerQueue QueueShort = new SoccerPlayerQueue();
		SoccerPlayerQueue QueueLong = new SoccerPlayerQueue();
		
		QueueShort.readFromFile("futbolDataShort.csv");
		QueueLong.readFromFile("futbolData.csv");
		
		System.out.println(QueueShort.comprehensiveFind("Cristiano Ronaldo"));
		System.out.println(QueueLong.comprehensiveFind("Cristiano Ronaldo"));
	}

}
