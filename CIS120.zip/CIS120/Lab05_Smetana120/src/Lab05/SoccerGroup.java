package Lab05;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import Lab04.LLStringNode;
import ch03.stacks.LLNode;
import ch03.stacks.LinkedStack;

public class SoccerGroup extends LinkedStack<SoccerPlayer> {
	
	String fileName;
	
	
	//Reading from a file
	public String readFromFile (String fileName) throws FileNotFoundException {
		File file = new File(fileName); //Creating new file to read what the user inputs
		Scanner inputFile = new Scanner(file); //Creating a Scanner
		
		String line = inputFile.nextLine(); //Inputing the next two lines
		line = inputFile.nextLine();
		
		String[] tokens = line.split(","); //Spliting on a ","
		
		while (inputFile.hasNextLine()) { //A loop that while it has a next line splits the tokens and assigns the tokens to a soccer player object
			line = inputFile.nextLine();
			tokens = line.split(",", -1);
			SoccerPlayer player = new SoccerPlayer(tokens[2], parseWithDefault(tokens[1], 0), parseWithDefault(tokens[3], 0),
					tokens[4], parseWithDefault(tokens[5], 0), parseWithDefault(tokens[6], 0), tokens[7], tokens[8],
					tokens[9], parseWithDefault(tokens[10], 0));
			
			super.push(player); //Pushing it onto the top of the stack
		}
		
		
		inputFile.close(); //Close file
		return fileName; //return file
	}
	
	public int countNationality (String nation) {
	
		int x = 0; //Variable set to 0 to add later
		LLNode<SoccerPlayer> currentNode = super.top; ///Making a currentNode thats setting equal to log

		do {
			if (currentNode.getInfo().getNationality().compareTo(nation) == 0) { //CurrentNode is comparing to element
				x++; //Add x if its equal
			}
			currentNode = currentNode.getLink();
		} while (currentNode.getLink() != null); //If it doesnt equal

		return x; //Return our counting variable

	
	}
	
	//Took from:
	//https://stackoverflow.com/questions/1486077/good-way-to-encapsulate-integer-parseint
	//09/24/2020
	public static int parseWithDefault(String number, int defaultVal) {
		  try {
		    return Integer.parseInt(number);
		  } catch (NumberFormatException e) {
		    return defaultVal;
		  }
		}

}
