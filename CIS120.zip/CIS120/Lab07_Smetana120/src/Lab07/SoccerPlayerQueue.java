package Lab07;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import ch05.queues.*;

public class SoccerPlayerQueue extends ArrayUnbndQueue<SoccerPlayer> {

	public String readFromFile(String fileName) throws FileNotFoundException {
		File file = new File(fileName); // Creating new file to read what the user inputs
		Scanner inputFile = new Scanner(file); // Creating a Scanner

		String line = inputFile.nextLine(); // Inputing the next two lines
		line = inputFile.nextLine();

		String[] tokens = line.split(","); // Spliting on a ","

		while (inputFile.hasNextLine()) { // A loop that while it has a next line splits the tokens and assigns the
											// tokens to a soccer player object
			line = inputFile.nextLine();
			tokens = line.split(",", -1);
			SoccerPlayer player = new SoccerPlayer(tokens[2], parseWithDefault(tokens[1], 0),
					parseWithDefault(tokens[3], 0), tokens[4], parseWithDefault(tokens[5], 0),
					parseWithDefault(tokens[6], 0), tokens[7], tokens[8], tokens[9], parseWithDefault(tokens[10], 0));

			this.enqueue(player); // Pushing it onto the top of the queue
		}

		inputFile.close(); // Close file
		return fileName; // return file
	}

	public String comprehensiveFind(String word) {

		SoccerPlayerQueue players = new SoccerPlayerQueue(); //Creating a 2nd queue
		StringBuilder PlayerList = new StringBuilder(); //String builder to convert queue into strings

		do {
			SoccerPlayer FrontElement = this.dequeue(); //Creating front element and deque it

			if (FrontElement.getName().contains(word) || //If front element has the name or
					FrontElement.getNationality().contains(word)|| //has the Nationality
					FrontElement.getClub().contains(word)) { //has the club
				PlayerList.append(FrontElement.getName()); //Then we append the name
				PlayerList.append(";"); //Split it by semi colon
			}
			players.enqueue(FrontElement); //Enqueue
		} while (!this.isEmpty());

		do {
			SoccerPlayer FrontElement = players.dequeue(); //Put on another stack
			this.enqueue(FrontElement); //Enqueue it
		} while (!players.isEmpty());

		return PlayerList.toString(); //Return it
	}

	// Took from:
	// https://stackoverflow.com/questions/1486077/good-way-to-encapsulate-integer-parseint
	// 09/24/2020
	public static int parseWithDefault(String number, int defaultVal) {
		try {
			return Integer.parseInt(number);
		} catch (NumberFormatException e) {
			return defaultVal;
		}
	}

}
