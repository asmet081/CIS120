package Lab11;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import ch09.priorityQueues.*;

public class Tester {


	
	public static void main(String[] args) throws FileNotFoundException {
		
		//BUILDING THE QUEUE
		PriQueueInterface<SoccerPlayer> bst = new Heap<SoccerPlayer>(20000); //Creating heap
		
		long startTime = System.nanoTime();
		PriQueueInterface<String> name = new Heap<String>(20000);
		long estimatedTime = System.nanoTime() - startTime;
		System.out.println("Building the name Queue:" + " " + estimatedTime); //Printing out
		
		
		startTime = System.nanoTime();
		PriQueueInterface<Integer> rating = new Heap<Integer>(20000);
		estimatedTime = System.nanoTime() - startTime;
		System.out.println("Building the rating Queue:" + " " + estimatedTime); //Printing out
		
		
		startTime = System.nanoTime();
		PriQueueInterface<Integer> potential = new Heap<Integer>(20000);
		estimatedTime = System.nanoTime() - startTime;
		System.out.println("Building the potential Queue:" + " " + estimatedTime); //Printing out

		System.out.println(" "); //Break line
		
		//ENQUEUEING
		startTime = System.nanoTime();
		readFromFile("futbolDataShort.csv", bst, name, rating, potential);//Read from file modified from last lab
		estimatedTime = System.nanoTime() - startTime;
		System.out.println("Enqueuing:" + " " + estimatedTime); //Printing out
		 
		System.out.println(" "); //Break line
		
		//DEQUEUEING
		startTime = System.nanoTime();
		while (!name.isEmpty()) {
			name.dequeue();
		}
		estimatedTime = System.nanoTime() - startTime;
		System.out.println("Dequeing name:" + " " + estimatedTime); //Printing out
		
		startTime = System.nanoTime();
		while (!rating.isEmpty()) {
			rating.dequeue();
		}
		estimatedTime = System.nanoTime() - startTime;
		System.out.println("Dequeing rating:" + " " + estimatedTime); //Printing out
		
		startTime = System.nanoTime();
		while (!potential.isEmpty()) {;
			potential.dequeue();
		}
		estimatedTime = System.nanoTime() - startTime;
		System.out.println("Dequeing potential:" + " " + estimatedTime); //Printing out
	}

	//This method is the same as previous labs except with PriQueueInterface/Enqueueing
	public static String readFromFile(String fileName, PriQueueInterface<SoccerPlayer> bst, PriQueueInterface<String> name, PriQueueInterface<Integer> overallRating, PriQueueInterface<Integer> potential) throws FileNotFoundException {
		File file = new File(fileName); // Creating new file to read what the user inputs
		Scanner inputFile = new Scanner(file); // Creating a Scanner

		String line = inputFile.nextLine(); // Inputing the next two lines
		line = inputFile.nextLine();

		String[] tokens = line.split(","); // Spliting on a ","

		while (inputFile.hasNextLine()) { // A loop that while it has a next line splits the tokens and assigns the
											// tokens to a soccer player object
			line = inputFile.nextLine();
			tokens = line.split(",", -1);
			SoccerPlayer player = new SoccerPlayer(tokens[2], parseWithDefault(tokens[1], 0),
					parseWithDefault(tokens[3], 0), tokens[4], parseWithDefault(tokens[5], 0),
					parseWithDefault(tokens[6], 0), tokens[7], tokens[8], tokens[9], parseWithDefault(tokens[10], 0));

			bst.enqueue(player); // Enqueing
			name.enqueue(player.getName());
			overallRating.enqueue(player.getOverallRating());
			potential.enqueue(player.getPotential());
			
		}

		inputFile.close(); // Close file
		return fileName; // return file
	}
	
	
	//Recycled from old lab
	public static int parseWithDefault(String number, int defaultVal) {
		try {
			return Integer.parseInt(number);
		} catch (NumberFormatException e) {
			return defaultVal;
		}
	}
	
	
}
