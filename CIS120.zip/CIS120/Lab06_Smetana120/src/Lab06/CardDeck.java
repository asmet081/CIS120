package Lab06;

import ch03.stacks.BoundedStackInterface;
import ch03.stacks.ArrayStack;

public class CardDeck<T> implements CardDeckInterface<T> 
{

	BoundedStackInterface<T> Cards = new ArrayStack<T>();
	
	public CardDeck(int size) { //Construtor
		Cards = new ArrayStack<T>(size);
	}


	//Deals one card from the top
	public T dealOneCard() {
		
		if (!Cards.isEmpty()) { //If card is empty
			T card = Cards.top(); //Card is top
			Cards.pop(); //Pop card
			return card; //return card
		}
		throw new StackUnderflowException("No Cards In the Deck"); //If theres no card print message
	}
		

	public BoundedStackInterface<T> dealNCards(int NumberOfCards) throws StackUnderflowException {
		BoundedStackInterface<T> Hand = new ArrayStack<T>();
		
		for  (int x = 0; x < NumberOfCards; x++) { //If x < number of cards add loop
			Hand.push(Cards.top()); //Push the top into hand
			Cards.pop(); //pop it
		}
		return Hand; //Return hand
	}
	
	
	public void  addCard(T Card) {
		  //Add a card to the top of the deck
		
		if (!Cards.isFull()) { //If cards is not full
			Cards.push(Card); //Push the card to top
		}
		else
		throw new StackOverflowException("Deck is full"); //Otherwise return error

	}


}
