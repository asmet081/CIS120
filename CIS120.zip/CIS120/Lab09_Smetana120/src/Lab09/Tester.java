package Lab09;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.Scanner;
import ch06.lists.*;

public class Tester{

	static ListInterface<SoccerPlayer> list1 = new ArrayUnsortedList<SoccerPlayer>(20000);
	static ListInterface<SoccerPlayer> list2 = new ArraySortedList<SoccerPlayer>(20000);
	static ListInterface<SoccerPlayer> list3 = new ArraySortedList2<SoccerPlayer>(20000);
	static ListInterface<SoccerPlayer> list4 = new ArraySortedList3<SoccerPlayer>(20000);
	static ListInterface<SoccerPlayer> list5 = new RefUnsortedList<SoccerPlayer>();
	static ListInterface<SoccerPlayer> list6 = new RefSortedList<SoccerPlayer>();
	
	public static void main(String[] args) throws FileNotFoundException {
		
		long startTime = System.nanoTime();
		readFromFile("futbolData.csv", list1);
		long estimatedTime = System.nanoTime() - startTime;
		System.out.print("ArrayUnsortedList:" + " ");
		System.out.println(estimatedTime);
		
		startTime = System.nanoTime();
		readFromFile("futbolDataShort.csv", list2);
		estimatedTime = System.nanoTime() - startTime;
		System.out.print("ArraySortedList:" + " ");
		System.out.println(estimatedTime);
		
		startTime = System.nanoTime();
		readFromFile("futbolDataShort.csv", list3);
		estimatedTime = System.nanoTime() - startTime;
		System.out.print("ArraySortedList2:" + " ");
		System.out.println(estimatedTime);
		
		startTime = System.nanoTime();
		readFromFile("futbolDataShort.csv", list4);
		estimatedTime = System.nanoTime() - startTime;
		System.out.print("ArraySortedList3:" + " ");
		System.out.println(estimatedTime);
		
		startTime = System.nanoTime();
		readFromFile("futbolDataShort.csv", list5);
		estimatedTime = System.nanoTime() - startTime;
		System.out.print("RefUnsortedList:" + " ");
		System.out.println(estimatedTime);
		
		startTime = System.nanoTime();
		readFromFile("futbolDataShort.csv", list6);
		estimatedTime = System.nanoTime() - startTime;
		System.out.print("RefUnsortedList:" + " ");
		System.out.println(estimatedTime);
	}
	
	public static String readFromFile(String fileName, ListInterface<SoccerPlayer> list) throws FileNotFoundException {
		File file = new File(fileName); // Creating new file to read what the user inputs
		Scanner inputFile = new Scanner(file); // Creating a Scanner

		String line = inputFile.nextLine(); // Inputing the next two lines
		line = inputFile.nextLine();

		String[] tokens = line.split(","); // Spliting on a ","

		while (inputFile.hasNextLine()) { // A loop that while it has a next line splits the tokens and assigns the
											// tokens to a soccer player object
			line = inputFile.nextLine();
			tokens = line.split(",", -1);
			SoccerPlayer player = new SoccerPlayer(tokens[2], parseWithDefault(tokens[1], 0),
					parseWithDefault(tokens[3], 0), tokens[4], parseWithDefault(tokens[5], 0),
					parseWithDefault(tokens[6], 0), tokens[7], tokens[8], tokens[9], parseWithDefault(tokens[10], 0));

			list.add(player); // Pushing it onto the top of the queue
		}

		inputFile.close(); // Close file
		return fileName; // return file
	}

	public static int parseWithDefault(String number, int defaultVal) {
		try {
			return Integer.parseInt(number);
		} catch (NumberFormatException e) {
			return defaultVal;
		}
	}
}
