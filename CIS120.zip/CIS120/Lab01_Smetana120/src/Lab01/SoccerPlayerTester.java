//Alex Smetana
//Lab01 - Classees
//Data Structures and Algorithms
//09/04/2020

package Lab01;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class SoccerPlayerTester {

	//Main Method for testing the soccer player class
	public static void main(String[] args) throws IOException {

		// Open the file.
		File file = new File("futbolDataShort.txt");
		Scanner inputFile = new Scanner(file);
		
		String line = inputFile.nextLine();
		
		SoccerPlayer[] players = new SoccerPlayer[5];
	
		int x = 0;
		
		while(inputFile.hasNext())
		{
			line = inputFile.nextLine();
			
			String[] tokens = line.split("\t");
			SoccerPlayer player = new SoccerPlayer(tokens[2], Integer.parseInt(tokens[1]), Integer.parseInt(tokens[3]), tokens[4], Integer.parseInt(tokens[5]), Integer.parseInt(tokens[6]), tokens[7], tokens[8], tokens[9], Integer.parseInt(tokens[10]));

			//System.out.println(player.toString());
			
			players[x] = player;
			x++;
		}

		// Close the file.
		inputFile.close();

		for (int y = 0; y < 5; y++) {
			System.out.println(players[y]);
		}

		
	}
	

}
