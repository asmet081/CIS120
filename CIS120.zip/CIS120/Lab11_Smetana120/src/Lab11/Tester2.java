package Lab11;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import ch09.priorityQueues.Heap;
import ch09.priorityQueues.PriQueueInterface;

public class Tester2 {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub

		File file = new File("futbolDataMedium.csv"); // Creating new file to read what the user inputs
		Scanner inputFile = new Scanner(file); // Creating a Scanner

		String line = inputFile.nextLine(); // Inputing the next two lines
		
		PriQueueInterface<SoccerPlayer> bst = new Heap<SoccerPlayer>(20000); //Creating heap
		readFromFile(inputFile, bst, 10);//Read from file modified from last lab
		
	    System.out.println("10 item Heap" + bst);
		
		readFromFile(inputFile, bst, 1);//Read from file modified from last lab
	    System.out.println("Enqueing 1" + " " + bst);
	    System.out.println(" ");
	    System.out.println(" ");
	    System.out.println(" ");
		readFromFile(inputFile, bst, 1);
	    System.out.println("Enqueing 2" + " " + bst);
	    System.out.println(" ");
	    System.out.println(" ");
	    System.out.println(" ");
		readFromFile(inputFile, bst, 1);
	    System.out.println("Enqueing 3" + " " + bst);
	    System.out.println(" ");
	    System.out.println(" ");
	    System.out.println(" ");
	    
	    for(int x = 0; x < 5; x++) {
	    	bst.dequeue();
	    }
		
	    System.out.println("Dequeing 5" + " " + bst);
		
		
		inputFile.close(); // Close file
	}

	public static void readFromFile(Scanner inputFile, PriQueueInterface<SoccerPlayer> bst, int count) throws FileNotFoundException {

		String line = inputFile.nextLine();

		String[] tokens = line.split(","); // Spliting on a ","
		
		for (int x = 0; x < count; x++) {
			line = inputFile.nextLine();
			tokens = line.split(",", -1);
			SoccerPlayer player = new SoccerPlayer(tokens[2], parseWithDefault(tokens[1], 0),
					parseWithDefault(tokens[3], 0), tokens[4], parseWithDefault(tokens[5], 0),
					parseWithDefault(tokens[6], 0), tokens[7], tokens[8], tokens[9], parseWithDefault(tokens[10], 0));

			bst.enqueue(player); // Enqueing
		}


	}	
	
	//Recycled from old lab
	public static int parseWithDefault(String number, int defaultVal) {
		try {
			return Integer.parseInt(number);
		} catch (NumberFormatException e) {
			return defaultVal;
		}
	}	
	
}
